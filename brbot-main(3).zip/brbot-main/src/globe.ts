import { Telegraf } from "telegraf"
import { DB } from "./db"
import * as cfg from "./config"


export let
  db = new DB(),
  bot = new Telegraf(cfg.tgToken)

