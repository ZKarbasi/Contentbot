import { CallbackQuery, InlineKeyboardButton, Message, ReplyKeyboardMarkup } from "telegraf/typings/core/types/typegram"
import { Dict } from "./helper"


export type TelegramMessageType =
  "text" |
  "document" |
  "other"

export function msgkind(m?: Message): TelegramMessageType {
  let d = raw(m)

  if (d == null || d == undefined) return "other"
  else if ("text" in d) return "text"
  else if ("document" in d) return "document"
  else return "other"
}

export function raw<T>(t?: T): Dict {
  return <Dict>(t)
}
export function getFileName(m?: Message): string {
  return m ? raw(m)["document"]["file_name"] : ""
}
export function getDocId(m?: Message): string {
  return m ? raw(m)["document"]["file_id"] : ""
}
export function msgText(m?: Message): string {
  return m ? <string>raw(m)["text"] : ""
}
export function isCommand(t: string | null): boolean {
  return t ? t.startsWith('/') : false
}
export function cbData(cbq: CallbackQuery | undefined): string {
  return cbq ? <string>raw(cbq)["data"] || "" : ""
}

export function cbInlineQButton(text: string, prompt: string = "") {
  return {
    text,
    switch_inline_query_current_chat: prompt,
  }
}
export function cbButton(text: string, callback_data: string) {
  return { text, callback_data }
}
export function glassKeyboardGroup(keyboard: InlineKeyboardButton[][]) {
  return {
    reply_markup: {
      inline_keyboard:
        keyboard
    }
  }
}

export function replied_msg_id(m?: Message) {
  if (m) {
    let
      r = raw(m),
      rtm = r["reply_to_message"]

    if (rtm) {
      // @ts-ignore
      return rtm["message_id"] as number
    }
  }
}