import { InputType } from "zlib"
import { TelegramMessageType } from "./telegram"

export interface Dict {
    [key: string]: any
}

export function toMap<V, T>(seq: V[], keygen: ((v: V) => string), valuegen: ((v: V) => T)) {
    var result: { [key: string]: T } = {}
    for (const s of seq)
        result[keygen(s)] = valuegen(s)
    return result
}

export function objLen(obj: object) {
    return Object.keys(obj).length
}

export function parseCommand(text: string): { cmd: string, params: string[] } {
    let parts = text.split(" ")
    return { cmd: parts[0], params: parts.slice(1) }
}
export function makeQueryCmd(command: string, ...params: string[]): string {
    return [command, ...params].join(":")
}
export function parseQuery(line: string): { cmd: string, params: string[] } {
    let temp = line.split(":")
    return {
        cmd: temp[0],
        params: temp.slice(1)
    }
}


export function damn(msg = "no error message provided"): never {
    throw new Error(msg)
}

export function deduplicateBy<T>(seq: T[], indicator: (item: T) => string): T[] {
    let store: Set<string> = new Set()
    return seq.filter(t => {
        let k = indicator(t)
        if (k in store) {
            return false
        }
        else {
            store.add(k)
            return true
        }
    })
}

export function expectMessageType(mkind: TelegramMessageType, ftype: InputType): boolean {
    return (
        (mkind == "text" && ftype == "text") ||
        (mkind == "document" && ftype == "file"))
}
