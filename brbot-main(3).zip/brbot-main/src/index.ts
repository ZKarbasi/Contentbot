import { bot, db } from "./globe"
import * as M from "./messages"
import { InputType, PurposeOfMessage, UserMajorState as UMS, UserMinorState as USS, matchesNameOrUsername, rawFlowField } from "./db"

import { Context } from "telegraf"
import { askNext, filledFormEditPermission, formRelatedUsers, prepareSendMessage, returnToHome, sendFilledForm, sendFormFieldEditReport, sendFormFlowFields, sendUserContact, updateForm } from "./actions"
import { cbData, isCommand, msgText, msgkind, glassKeyboardGroup, getDocId, getFileName, replied_msg_id } from "./telegram"
import { userShortInfoIQ } from "./messages"
import { Dict, parseQuery, parseCommand, expectMessageType } from "./helper"
import { TELEGRAM_BOT_TOKEN_KEY, tgToken } from "./config"

async function dispatcher(ctx: Context) {
    try {
        let
            chatid = ctx.from?.id || -1,
            uname = ctx.from?.username || "_",
            echid = db.existsUser(chatid),
            euname = db.existsUsername(uname),
            uexists = euname || echid,
            rpl_msg_id = replied_msg_id(ctx.message),

            txt = msgText(ctx.message),
            q = cbData(ctx.callbackQuery),
            c = parseQuery(q),
            isMsg = ctx.message != null,
            isTxt = txt != "",
            isCbq = ctx.callbackQuery != null,
            isInlineQ = ctx.inlineQuery != null,
            answered = false,
            answer = ""

        if (euname && !echid) {
            await db.setChatId(uname, chatid)
            await bot.telegram.sendMessage(chatid, M.weveBeenwaitingForYouM)
        }
        if (!uexists) {
            await ctx.sendMessage(M.sorryYoureNotRegisteredM)
        }
        else {
            let
                u = db.getUser(chatid),
                s = db.getUserState(chatid)

            if (!answered && isMsg && isCommand(txt)) {
                answered = true

                let l = parseCommand(txt)

                switch (l.cmd) {
                    case M.startC:
                        await ctx.sendMessage(M.helpM, glassKeyboardGroup(
                            u.is_admin
                                ? M.helpAdminsK()
                                : M.helpUsersK()))
                        returnToHome(u)
                        break

                    case M.debugC:
                        await ctx.sendMessage(JSON.stringify(s, null, 4))
                        break

                    case M.sendMessageC:
                        let chid2 = db.getUsername(l.params[0]).tg_chatid
                        prepareSendMessage(chatid, chid2)
                        break

                    case M.selectUserC:
                        if (l.params.length == 1 && u.is_admin) {
                            let uname2 = l.params[0]

                            if (db.existsUsername(uname2))
                                sendUserContact(ctx, db.getUsername(uname2))
                        }
                        break

                    default:
                        ctx.reply(M.invalidCommandM)
                }
            } if (!answered && rpl_msg_id) {
                let rm = await db.getArchived(u.tg_chatid || 0, rpl_msg_id)
                if (rm) {
                    answered = true

                    switch (rm.kind) {
                        case PurposeOfMessage.formReport: {
                            let
                                fid = rm.form_id ?? 0,
                                form = await db.getForm(fid),
                                msg_for_owner = await db.getArchivedFormReportMsg(form.user_chat_id, form.id),
                                msg_id_to_reply = msg_for_owner?.msg_id || 0,
                                repl = await ctx.copyMessage(form.user_chat_id, {
                                    reply_to_message_id: msg_id_to_reply
                                }),
                                arch = await db.archiveConversation(
                                    form.user_chat_id,
                                    repl.message_id,
                                    u.tg_chatid || 0,
                                    ctx.message?.message_id || 0)
                            break
                        }
                        case PurposeOfMessage.userConversation: {
                            let
                                recv_tg_id = rm.reply_to_user_chatid || 0,
                                rcvr_msg_id_repl = rm.reply_to_msg_id || 0,
                                repl = await ctx.copyMessage(recv_tg_id, {
                                    reply_to_message_id: rcvr_msg_id_repl
                                }),
                                arch = await db.archiveConversation(
                                    recv_tg_id,
                                    repl.message_id,
                                    u.tg_chatid || 0,
                                    ctx.message?.message_id || 0)
                            break
                        }
                    }
                }
                else {
                    await ctx.sendMessage(M.repliedMessageDoesNotreferToAnythingM)
                }
            } if (!answered && isInlineQ) {
                answered = true

                let contactList = u.is_admin
                    ? db.usersList
                    : db.getAdmins()

                ctx.answerInlineQuery(
                    contactList
                        .filter(u => matchesNameOrUsername(u, q))
                        .map(o => userShortInfoIQ(u, o)), {
                    cache_time: 10,
                    is_personal: true
                })
            } if (!answered && isCbq && q == M.cancelB) {
                answered = true
                await ctx.sendMessage(M.youCanceledM)
                returnToHome(u)
            } if (!answered && s.master == UMS.sendMessage && isMsg) {
                answered = true
                let
                    recv_chat_id = s.data.sendMsg?.dest_tgid || -1,
                    fmsg = await ctx.forwardMessage(recv_chat_id),
                    arch = await db.archiveConversation(
                        recv_chat_id,
                        fmsg.message_id,
                        u.tg_chatid || 0,
                        ctx.message?.message_id || 0)

                returnToHome(u)
            } if (!answered && s.master == UMS.fillForm) {
                answered = true

                function add(n: string, d: InputType, t: string) {
                    s.data.fillingForm?.answers.push({
                        name: n,
                        data_type: d,
                        value: t
                    })
                }
                let ok = true

                if (s.data.fillingForm) {
                    if (isMsg) {
                        let i = s.data.fillingForm?.fieldIndex || 0

                        if (s.data.fillingForm) { // annoying ts ........ ugh
                            let
                                field = db.theForm[i],
                                ftype = field.data_type,
                                mkind = msgkind(ctx.message)


                            if (mkind == "text" && ftype == "text") {
                                add(field.name, field.data_type, txt)
                            }
                            else if (mkind == "document" && ftype == "file") {
                                let fname = getFileName(ctx.message).toLocaleLowerCase()

                                function add2() {
                                    add(field.name, field.data_type, getDocId(ctx.message))
                                }
                                if (field.valid_extensions) {
                                    if (field.valid_extensions.some(ext => fname.endsWith(ext))) {
                                        add2()
                                    }
                                    else {
                                        ok = false
                                        await ctx.sendMessage(
                                            M.fileFormatDoesNotMatchM +
                                            "\n\n" +
                                            field.valid_extensions.join(" "))
                                    }
                                }
                                else {
                                    add2()
                                }
                            }
                            else {
                                await ctx.sendMessage(M.typeOfMessageDoesNotSatisfiesFieldTypeM(ftype, mkind))
                                ok = false
                            }
                        }
                    }
                    else if (isCbq) {
                        let
                            suggestionIndex = parseInt(c.params[0]),
                            fi = s.data.fillingForm?.fieldIndex ?? -1

                        if (fi < db.theForm.length && suggestionIndex) {
                            let field = db.theForm[fi]

                            if (suggestionIndex < field.suggestions.length) {
                                add(field.name, field.data_type, field.suggestions[suggestionIndex])
                            }
                            else {
                                ok = false
                                answer = M.somethingWentWrongStartAgainM
                            }
                        }
                        else {
                            ok = false
                            answer = M.somethingWentWrongStartAgainM
                        }

                        await ctx.answerCbQuery(answer)
                    }
                    else {
                        answered = false
                    }
                    if (ok) {
                        s.data.fillingForm.fieldIndex++
                        askNext(db, u, s, s.data.fillingForm.fieldIndex)
                    }
                }
            } if (!answered && s.master == UMS.addUser && isMsg && isTxt) {
                answered = true

                let wrapper
                switch (s.slave) {
                    case USS.setUserTelegramId:
                        wrapper = s.data.addUser || <Dict>({})
                        wrapper["username"] = txt.replace("@", "")
                        await ctx.sendMessage(M.enterUsernameM)
                        db.updateUserState(chatid,
                            UMS.addUser,
                            USS.setUsername,
                            s.data)
                        break

                    case USS.setUsername:
                        wrapper = s.data.addUser || <Dict>({})
                        wrapper["name"] = txt

                        db.updateUserState(chatid,
                            UMS.addUser,
                            USS.setUserIsAdmin,
                            s.data)

                        let u = await db.addUser({
                            name: wrapper.name,
                            username: wrapper.username,
                            is_admin: wrapper.is_admin,
                            tg_chatid: null
                        })
                        sendUserContact(ctx, u)
                        returnToHome(u)
                        break

                    default:
                        break
                }
            } if (!answered && s.master == UMS.editUser && isMsg && isTxt) {
                answered = true

                if (s.slave == USS.setUserTelegramId) {
                    let id = s.data.user?.id || -1
                    await db.updateUserTelegramId(id, txt)
                }
                else if (s.slave == USS.setUsername) {
                    let id = s.data.user?.id || -1
                    await db.updateUserName(id, txt)
                }
                returnToHome(u)
                await db.syncUsers()
                sendUserContact(ctx, db.getUser(s.data.user?.tg_chatid ?? -1))

            } if (!answered && s.master == UMS.filledFormAddField) {
                answered = true

                switch (s.slave) {
                    case USS.filledFormAddFieldName:
                        if (isTxt && s.data.addingFieldToFilledForm) {
                            s.data.addingFieldToFilledForm.field.name = txt
                            db.updateUserState(u.tg_chatid,
                                UMS.filledFormAddField,
                                USS.filledFormAddFieldType,
                                s.data)

                            await ctx.sendMessage(M.enterTypeOfFieldM, glassKeyboardGroup(M.fieldTypesK()))
                        }
                        break

                    case USS.filledFormAddFieldType:
                        if (isCbq && s.data.addingFieldToFilledForm) {
                            if (q == "text" || q == "file") {
                                s.data.addingFieldToFilledForm.field.data_type = q
                                db.updateUserState(u.tg_chatid,
                                    UMS.filledFormAddField,
                                    USS.filledFormAddFieldValue,
                                    s.data)

                                await ctx.sendMessage(M.sendTheValueM)
                            }
                            else {
                                await ctx.answerCbQuery(M.invalidCommandM)
                            }
                        }
                        break

                    case USS.filledFormAddFieldValue:
                        if (isMsg && s.data.addingFieldToFilledForm) {
                            let
                                mkind = msgkind(ctx.message),
                                ftype = s.data.addingFieldToFilledForm.field.data_type

                            if (expectMessageType(mkind, ftype)) {
                                let
                                    fid = s.data.addingFieldToFilledForm.formId,
                                    form = await db.getForm(fid),
                                    val =
                                        (mkind == "document")
                                            ? getFileName(ctx.message).toLocaleLowerCase()
                                            : txt

                                s.data.addingFieldToFilledForm.field.value = val
                                form.answers.push(s.data.addingFieldToFilledForm.field)
                                await db.updateFormAnswers(form.id, form.answers)

                                let newForm = await db.getForm(fid)


                                await sendFilledForm(formRelatedUsers(db, db.getUser(form.user_chat_id)), newForm, false, db)
                                await ctx.sendMessage(M.registeredM)
                            } else {
                                await ctx.sendMessage(M.typeOfMessageDoesNotSatisfiesFieldTypeM(ftype, mkind))
                            }
                        }
                        else if (isCbq) {
                            await ctx.answerCbQuery(M.invalidCommandM)
                        }
                        break
                }
            } if (!answered && s.master == UMS.filledFormEditField && isMsg) {
                answered = true

                if (s.data.editingFilledForm) {
                    let
                        { formId, fieldIndex } = s.data.editingFilledForm,
                        form = await db.getForm(formId),
                        mkind = msgkind(ctx.message),
                        fi = s.data.editingFilledForm.fieldIndex,
                        ftype = form.answers[fi].data_type

                    if (expectMessageType(mkind, ftype)) {
                        form.answers[fieldIndex].value = txt
                        await db.updateFormAnswers(formId, form.answers)

                        let newForm = await db.getForm(formId)
                        await sendFilledForm(formRelatedUsers(db, db.getUser(form.user_chat_id)), newForm, false, db)

                        await ctx.sendMessage(M.registeredM)
                        returnToHome(u)
                    }
                    else {
                        await ctx.sendMessage(M.typeOfMessageDoesNotSatisfiesFieldTypeM(ftype, mkind))
                    }
                }
            } if (!answered && s.master == UMS.flowEditCompleteMessage && isMsg && isTxt) {
                answered = true

                await db.setFormCompleteMessage(txt)
                await ctx.sendMessage(M.registeredM)
                returnToHome(u)
            } if (!answered && s.master == UMS.flowAddField || s.master == UMS.flowEditField) {
                answered = true

                if (s.data.formFlowField) {
                    switch (s.slave) {
                        case USS.setFlowFieldName: {
                            s.data.formFlowField.name = txt
                            db.updateUserState(u.tg_chatid,
                                s.master,
                                USS.setFlowFieldHasNote,
                                s.data)
                            await ctx.sendMessage(M.doesThisFieldHasDescription, M.yesNoCancelKeyboard)
                            break
                        }
                        case USS.setFlowFieldHasNote: {
                            if (q == M.yesB) {
                                db.updateUserState(u.tg_chatid,
                                    s.master,
                                    USS.setFlowFieldNote,
                                    s.data)

                                await ctx.sendMessage(M.enterّFieldNoteM, M.cancelKeyboard)
                            }
                            else if (q == M.noB) {
                                db.updateUserState(u.tg_chatid,
                                    s.master,
                                    USS.setFlowFieldType,
                                    s.data)
                                await ctx.sendMessage(M.enterTypeOfFieldM, glassKeyboardGroup(M.fieldTypesK()))
                            }
                            else {
                                await ctx.answerCbQuery(M.invalidCommandM)
                            }
                            break
                        }
                        case USS.setFlowFieldNote: {
                            s.data.formFlowField.note = txt
                            db.updateUserState(u.tg_chatid,
                                s.master,
                                USS.setFlowFieldType,
                                s.data)
                            await ctx.sendMessage(M.enterTypeOfFieldM, glassKeyboardGroup(M.fieldTypesK()))
                            break
                        }
                        case USS.setFlowFieldType: {
                            if (q == "text") {
                                s.data.formFlowField.data_type = q
                                db.updateUserState(u.tg_chatid,
                                    s.master,
                                    USS.setFlowFieldHasMoreSuggestion,
                                    s.data)

                                bot.telegram.sendMessage(u.tg_chatid ?? -1,
                                    M.doesThisFieldHasSuggestionsM, M.yesNoCancelKeyboard)
                            }
                            else if (q == "file") {
                                s.data.formFlowField.data_type = q
                                db.updateUserState(u.tg_chatid,
                                    s.master,
                                    USS.setFlowFieldFileFormats,
                                    s.data)

                                bot.telegram.sendMessage(u.tg_chatid ?? -1,
                                    M.enterValidFileFormatsM, M.cancelKeyboard)
                            }
                            else {
                                await ctx.answerCbQuery(M.invalidCommandM)
                            }
                            break
                        }
                        case USS.setFlowFieldFileFormats: {
                            s.data.formFlowField.valid_extensions =
                                (txt === "*")
                                    ? null
                                    : txt.toLowerCase().split(" ")
                            await updateForm(ctx, u, s, db.theForm, s.data.formFlowField)
                            returnToHome(u)
                            break
                        }
                        case USS.setFlowFieldHasMoreSuggestion: {
                            if (q == M.yesB) {
                                db.updateUserState(u.tg_chatid,
                                    s.master,
                                    USS.setFlowFieldAddSuggestion,
                                    s.data)

                                await ctx.sendMessage(M.enterFieldSuggestionM)
                            }
                            else if (q == M.noB) {
                                await updateForm(ctx, u, s, db.theForm, s.data.formFlowField)
                                returnToHome(u)
                            }
                            else {
                                console.assert(false)
                            }
                            break
                        }
                        case USS.setFlowFieldAddSuggestion: {
                            s.data.formFlowField.suggestions.push(txt)
                            db.updateUserState(u.tg_chatid,
                                s.master,
                                USS.setFlowFieldHasMoreSuggestion,
                                s.data)

                            await ctx.sendMessage(M.doesThisFieldHasSuggestionsM, M.yesNoCancelKeyboard)
                            break
                        }
                    }
                }
            } if (!answered && isCbq) {
                answered = true

                let
                    answer = q,
                    satisfied = true

                switch (c.cmd) { // normal users
                    case M.send_messageB:
                        prepareSendMessage(u.tg_chatid ?? -1, db.getUsername(c.params[0]).tg_chatid)
                        break

                    case M.fill_formB:
                        await ctx.sendMessage(M.fillTheFormThenM)
                        db.updateUserState(u.tg_chatid,
                            UMS.fillForm,
                            USS.doesNotHaveMinorState,
                            {
                                fillingForm: {
                                    fieldIndex: 0,
                                    answers: []
                                }
                            })

                        await askNext(db, u, s, 0)
                        break

                    case M.filled_form_edit_fieldB: {
                        let
                            formId = parseInt(c.params[0]),
                            form = await db.getForm(formId),

                            fieldIndex = parseInt(c.params[1]),
                            field = form.answers[fieldIndex]

                        filledFormEditPermission(u, form, async () => {
                            db.updateUserState(u.tg_chatid,
                                UMS.filledFormEditField,
                                USS.doesNotHaveMinorState,
                                {
                                    editingFilledForm: {
                                        formId,
                                        fieldIndex,
                                    }
                                })

                            await ctx.sendMessage(
                                M.enterNewValueForFieldM(field.name),
                                M.cancelKeyboard)
                        }, () => {
                            answer = M.normalUserCannotEditAcceptedFormM
                        })
                        break
                    }

                    case M.filled_form_editB: {
                        let
                            fid = parseInt(c.params[0]),
                            form = await db.getForm(fid)

                        filledFormEditPermission(u, form, () => {
                            sendFormFieldEditReport(ctx, u, form)
                        }, () => {
                            answer = M.normalUserCannotEditAcceptedFormM
                        })
                        break
                    }

                    default:
                        satisfied = false
                        break
                }
                if (!satisfied && u.is_admin) { // admins
                    switch (c.cmd) {
                        case M.add_userB: {
                            db.updateUserState(u.tg_chatid || -1,
                                UMS.addUser,
                                USS.setUserTelegramId,
                                {
                                    addUser: {
                                        username: "",
                                        name: "",
                                        is_admin: false
                                    }
                                })

                            await ctx.sendMessage(M.enterTelegramIdM, M.cancelKeyboard)
                            break
                        }
                        case M.remove_userB: {
                            let uname2 = c.params[0]
                            if (db.existsUsername(uname2)) {
                                let u2 = db.getUsername(uname2)
                                await db.removeUser(u2)
                                await ctx.sendMessage(M.userRemovedM(u2))
                            }
                            break
                        }

                        case M.edit_user_nameB: {
                            db.updateUserState(u.tg_chatid || -1,
                                UMS.editUser,
                                USS.setUsername,
                                {
                                    user: db.getUsername(c.params[0])
                                })

                            await ctx.sendMessage(M.enterUsernameM, M.cancelKeyboard)
                            break
                        }
                        case M.edit_user_tgidB: {
                            db.updateUserState(u.tg_chatid || -1,
                                UMS.editUser,
                                USS.setUserTelegramId,
                                {
                                    user: db.getUsername(c.params[0])
                                })
                            await ctx.sendMessage(M.enterTelegramIdM, M.cancelKeyboard)
                            break
                        }
                        case M.toggle_user_positionB: {
                            let unamee2 = c.params[0]

                            if (db.existsUsername(unamee2)) {
                                let u2 = db.getUsername(unamee2)

                                if (u2.tg_chatid == u.tg_chatid) {
                                    await ctx.sendMessage(M.cannotPoisitionOfYourselfM)
                                }
                                else {
                                    u2.is_admin = !u2.is_admin
                                    await db.updateUser(u2)
                                    sendUserContact(ctx, u2)
                                }
                            }
                            break
                        }

                        case M.form_flow_optionsB: {
                            sendFormFlowFields(u)
                            break
                        }

                        case M.add_form_flow_fieldB: {
                            db.updateUserState(u.tg_chatid,
                                UMS.flowAddField,
                                USS.setFlowFieldName, {
                                formFlowField: rawFlowField(),
                            })

                            await ctx.sendMessage(M.enterFieldNameM, M.cancelKeyboard)
                            break
                        }
                        case M.edit_form_flow_fieldB: {
                            let fieldIndex = parseInt(c.params[0])
                            db.updateUserState(u.tg_chatid,
                                UMS.flowEditField,
                                USS.setFlowFieldName, {
                                formFlowIndex: fieldIndex,
                                formFlowField: rawFlowField(),
                            })

                            await ctx.sendMessage(M.enterFieldNameM, M.cancelKeyboard)
                            break
                        }
                        case M.remove_form_flow_fieldB: {
                            let fieldIndex = parseInt(c.params[0])
                            db.theForm.splice(fieldIndex, 1)
                            await db.setFormFlow(db.theForm)
                            await ctx.sendMessage(M.fieldDeletedFromFormM)
                            await sendFormFlowFields(u)
                            break
                        }
                        case M.edit_form_complete_messageB: {
                            db.updateUserState(u.tg_chatid,
                                UMS.flowEditCompleteMessage,
                                USS.doesNotHaveMinorState)

                            await ctx.sendMessage(M.lastCompleteMessageWasM + db.getFormCompleteMessage())
                            await ctx.sendMessage(M.enterLastMessageM, M.cancelKeyboard)
                            break
                        }

                        case M.filled_form_add_fieldB: {
                            db.updateUserState(u.tg_chatid,
                                UMS.filledFormAddField,
                                USS.filledFormAddFieldName, {
                                addingFieldToFilledForm: {
                                    formId: parseInt(c.params[0]),
                                    field: {
                                        name: "",
                                        data_type: "text",
                                        value: ""
                                    }
                                }
                            })
                            await ctx.sendMessage(M.enterNameOfFieldM)
                            break
                        }

                        case M.filled_form_delete_fieldB: {
                            let
                                formId = parseInt(c.params[0]),
                                fieldIndex = parseInt(c.params[1]),
                                form = await db.getForm(formId)

                            filledFormEditPermission(u, form, async () => {
                                if (fieldIndex < form.answers.length) {
                                    form.answers.splice(fieldIndex, 1)
                                    await db.updateFormAnswers(formId, form.answers)
                                    await sendFilledForm(formRelatedUsers(db, db.getUser(form.user_chat_id)), form, false, db)
                                    await ctx.sendMessage(M.fieldDeletedFromFormM)
                                }
                                else {
                                    answer = M.invalidAccessM
                                }
                            }, () => {
                                answer = M.invalidAccessM
                            })

                            break
                        }

                        case M.accept_filled_formB: {
                            if (u.is_admin) {
                                let
                                    fid = parseInt(c.params[0]),
                                    chid = u.tg_chatid || 0,
                                    acpt = await db.acceptFilledForm(fid, chid, new Date()),
                                    reportMsgIds = await db.client.archivedMessage.findMany({
                                        select: { tg_chatid: true, msg_id: true },
                                        where: { form_id: fid },
                                    })

                                reportMsgIds
                                    .forEach((rm) => bot.telegram
                                        .sendMessage(rm.tg_chatid, M.acceptedByM(u), {
                                            reply_to_message_id: rm.msg_id
                                        })
                                    )

                            }
                            break
                        }

                        default:
                            satisfied = false
                    }
                }

                try {
                    await ctx.answerCbQuery(answer)
                }
                catch { }
            } if (!answered) {
                answered = true
                await ctx.sendMessage(M.itSeemsLikeYouveLostM)
            }
        }

    } catch (error) {
        console.log("Error::")
        console.log(error)

        await ctx.sendMessage(M.anErrorAccordM)
        let chid = ctx.message?.chat.id || ctx.callbackQuery?.from.id || ctx.inlineQuery?.from.id || 0

        console.log("State::")
        console.log(JSON.stringify(db.getUserState(chid)))

        console.log("Context::")
        console.log(JSON.stringify(ctx))
        console.log("---------------------")
    }
}
async function main() {
    if (tgToken == "") {
        console.error(`${TELEGRAM_BOT_TOKEN_KEY} is not set`)
    }
    else {
        console.info("initilizing bot ...")

        let myInfo = await bot.telegram.getMe()
        console.info(`bot username: @${myInfo.username}`)

        console.info("setting commands: ")
        bot.telegram.setMyCommands([
            { command: M.startC, description: M.startAgainT },
            { command: M.debugC, description: M.debugT },
        ])

        bot.on("message", dispatcher)
        bot.on("edited_message", dispatcher)
        bot.on("callback_query", dispatcher)
        bot.on("inline_query", dispatcher)

        bot.launch()
        console.info("bot started ...")
    }
}

main()