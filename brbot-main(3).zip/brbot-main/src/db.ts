import { PrismaClient, FilledForm, User, ArchivedMessage, FormAcceptance } from '@prisma/client'
import { defaultAdminUsernames } from './config'
import { Dict, damn, objLen, toMap } from './helper'
import { assert } from 'console'
import { defaultFormCompleteMsgM } from './messages'

// ------ helper

export function matchesNameOrUsername(u: User, q: string): boolean {
    return u.name.includes(q) || u.username?.includes(q)
}

// ------ types

export enum PurposeOfMessage {
    formReport,     // notification
    userConversation     // user & admins can talk to each other by repling to one's messages
}
export enum UserMajorState {
    home,

    fillForm,
    sendMessage,

    addUser,
    editUser,

    filledFormAddField,
    filledFormEditField,

    flowEditCompleteMessage,
    flowAddField,
    flowEditField,
}
export enum UserMinorState {
    doesNotHaveMinorState,

    setUserTelegramId,
    setUsername,
    setUserIsAdmin,

    setFlowFieldName,
    setFlowFieldHasNote,
    setFlowFieldNote,
    setFlowFieldType,
    setFlowFieldFileFormats,
    setFlowFieldHasMoreSuggestion,
    setFlowFieldAddSuggestion,

    filledFormAddFieldName,
    filledFormAddFieldType,
    filledFormAddFieldValue,
}

export type InputType = "file" | "text"

export type FormFlowField = {
    name: string
    note: string
    data_type: InputType
    valid_extensions: string[] | null
    suggestions: string[]
}
export type FormFieldAnswer = {
    name: string
    data_type: string
    value: string
}
export type FilledFormParsed =
    Omit<FilledForm, "answers"> &
    {
        answers: FormFieldAnswer[],
        acceptances: FormAcceptance[]
    }

export type UserState = {
    master: number
    slave: number
    data: InternalStateData
}
export type InternalStateData = {
    fillingForm?: {
        fieldIndex: number,
        answers: FormFieldAnswer[],
    },
    addUser?: {
        username: string,
        name: string,
        is_admin: boolean
    },
    user?: User,
    sendMsg?: {
        dest_tgid: number
    },
    editingFilledForm?: {
        formId: number,
        fieldIndex: number,
    },
    addingFieldToFilledForm?: {
        formId: number,
        field: FormFieldAnswer
    },
    formFlowIndex?: number,
    formFlowField?: FormFlowField,
}

// ------ initial db data

function adminsDBDefaultData(): Omit<User, "id">[] {
    if (defaultAdminUsernames.length == 0)
        damn("set default admins please")

    return defaultAdminUsernames.map(un => ({
        tg_chatid: null,
        name: `Admin ${un}`,
        username: un.toLowerCase(),
        is_admin: true
    }))
}

export function rawFlowField(): FormFlowField {
    return {
        data_type: "text",
        name: ".",
        note: "",
        valid_extensions: null,
        suggestions: []
    }
}

function toFormField(name: string, note: string, data_type: InputType, valid_extensions: string[] | null, suggestions: string[]): FormFlowField {
    return {
        name,
        note,
        data_type,
        valid_extensions,
        suggestions,
    }
}

function formFieldDBDefaultData() {
    return [
        toFormField("🌍 وب سایت", "اسم یا آدرس سایت", "text", null, [
            "گوگل",
            "سایت الکی 1",
            "سایت الکی2",
        ]),
        toFormField("✍️ عنوان محتوا", "عنوان محتوا به صورت واضح و مشخص و فارسی", "text", null, []),
        toFormField("💯  تعداد کلمات", "عدد باشه", "text", null, []),
        toFormField("📂 فایل محتوا", "حتما word باشه", "file", ["docs", "doc"], []),
    ]
}

export function initialInternalUserState(): UserState {
    return {
        master: UserMajorState.home,
        slave: UserMinorState.doesNotHaveMinorState,
        data: {}
    }
}

// ------ main

export class DB {
    client: PrismaClient

    // ------- cache
    usersList: User[]
    userChatIdMap: { [tg_chatid: string]: User }
    usernamesMap: { [username: string]: User }
    states: { [tg_chatid: string]: UserState }
    theForm: FormFlowField[]
    #settings: Dict

    async syncSettings() {
        this.#settings = toMap(await this.client.settings.findMany(), s => s.key, s => s.value)
        if (objLen(this.#settings) == 0) {
            await this.setFormFlow(formFieldDBDefaultData())
            await this.setFormCompleteMessage(defaultFormCompleteMsgM)
        }
    }
    async syncUsers() {
        this.usersList = await this.client.user.findMany()

        if (this.usersList.length == 0) {
            for (const u of adminsDBDefaultData())
                if (!this.existsUsername(u.username))
                    await this.addUserInDB(u)

            await this.syncUsers()
        }
        else {
            this.userChatIdMap = toMap(this.usersList, u => (u.tg_chatid ?? -1).toString(), u => u)
            this.usernamesMap = toMap(this.usersList, u => u.username.toLowerCase(), u => u)
        }
    }

    // ------- cache

    constructor() {
        this.client = new PrismaClient()

        this.usersList = []
        this.userChatIdMap = {}
        this.states = {}
        this.usernamesMap = {}
        this.theForm = []
        this.#settings = {}

        this.initDB()
    }
    async initDB() {
        await this.syncSettings()
        await this.syncUsers()
        this.theForm = this.getFormFlow()
    }
    // ------- db works

    isAdmin(tg_chatid: number): boolean {
        return (
            this.existsUser(tg_chatid) &&
            this.getUser(tg_chatid).is_admin)
    }
    async addUserInDB(u: Omit<User, "id">): Promise<User> {
        return await this.client.user.upsert({
            where: { username: u.username },
            create: u,
            update: u,
        })
    }
    async updateUserTelegramId(id: number, username: string) {
        await this.client.user.update({
            data: { username },
            where: { id }
        })
    }

    async updateUserName(id: number, name: string) {
        await this.client.user.update({
            data: { name },
            where: { id }
        })
    }
    async addUser(u: Omit<User, "id">): Promise<User> {
        let result = await this.addUserInDB(u)
        await this.syncUsers()
        return result
    }
    async removeUser(u: User) {
        this.client.user.delete({
            where: { id: u.id },
        })
        this.syncUsers()
    }

    getUser(tg_chatid: number): User {
        return this.userChatIdMap[tg_chatid]
    }
    getAdmins(): User[] {
        return this.usersList.filter(u => u.is_admin)
    }
    getUsername(name: string): User {
        return this.usernamesMap[name.toLowerCase()]
    }
    existsUser(tg_chatid: number): boolean {
        return tg_chatid in this.userChatIdMap
    }
    existsUsername(uname: string): boolean {
        return uname.toLowerCase() in this.usernamesMap
    }
    async setChatId(username: string, tg_chatid: number) {
        await this.client.user.update({
            data: { tg_chatid },
            where: { username }
        })
        await this.syncUsers()
    }
    async updateUser(u: User) {
        await this.client.user.update({
            data: u,
            where: { id: u.id }
        })
    }
    updateUserStatePacked(tg_chatid: number, s: UserState) {
        this.states[tg_chatid] = s
    }
    updateUserState(tg_chatid: number | null, major: number, minor: number, data: InternalStateData = {}) {
        if (tg_chatid)
            this.updateUserStatePacked(tg_chatid, { master: major, slave: minor, data })
    }
    getUserState(tg_chatid: number): UserState {
        if (!(tg_chatid in this.states)) {
            this.states[tg_chatid] = initialInternalUserState()
        }
        return this.states[tg_chatid]
    }

    getSetting(key: string): string {
        return this.#settings[key]
    }
    existsSetting(key: string): boolean {
        return key in this.#settings
    }
    async updateSetting(key: string, value: string) {
        await this.client.settings.upsert({
            where: { key },
            create: { key, value },
            update: { key, value },
        })
        this.#settings[key] = value
    }

    async addForm(f: FilledForm) {
    }

    async getForm(form_id: number): Promise<FilledFormParsed> {
        let f = await this.client.filledForm.findFirstOrThrow({
            where: { id: form_id },
            include: {
                acceptances: true
            }
        })

        return {
            ...f,
            answers: JSON.parse(f.answers) as FormFieldAnswer[]
        }
    }

    async updateFormAnswers(form_id: number, answers: FormFieldAnswer[]): Promise<void> {
        await this.client.filledForm.update({
            data: { answers: JSON.stringify(answers) },
            where: { id: form_id },
        })
    }

    formCompleteMessageKey = "fcmk"
    getFormCompleteMessage(): string {
        return this.getSetting(this.formCompleteMessageKey)
    }
    async setFormCompleteMessage(msg: string) {
        await this.updateSetting(this.formCompleteMessageKey, msg)
    }

    formFlowKey = "ffk"
    getFormFlow(): FormFlowField[] {
        return JSON.parse(this.getSetting(this.formFlowKey)) as FormFlowField[]
    }
    async setFormFlow(fields: FormFlowField[]) {
        await this.updateSetting(this.formFlowKey, JSON.stringify(fields))
        this.theForm = fields
    }

    async acceptFilledForm(form_id: number, user_chatid: number, timestamp: Date) {
        return await this.client.formAcceptance.create({
            data: {
                form_id,
                accepted_by_tg_chatid: user_chatid,
                timestamp,
            }
        })
    }

    async saveFilledForm(user_chat_id: number, answers: string, timestamp: Date) {
        return await this.client.filledForm.create({
            data: {
                user_chat_id,
                answers,
                timestamp
            }
        })
    }

    async archiveFormReportSent(form_id: number, sender_chat_id: number, msg_id: number) {
        await this.client.archivedMessage.create({
            data: {
                form_id,
                tg_chatid: sender_chat_id,
                msg_id,
                kind: PurposeOfMessage.formReport
            }
        })
    }

    async updateArchiveFormReportSent(form_id: number, sender_chat_id: number, msg_id: number) {
        await this.client.archivedMessage.updateMany({
            where: {
                form_id,
                tg_chatid: sender_chat_id,
            },
            data: { msg_id }
        })
    }

    async getArchivedFormReportMsg(chat_id: number, form_id: number) {
        return await this.client.archivedMessage.findFirst({
            where: {
                form_id,
                tg_chatid: chat_id,
            }
        })
    }
    async getArchived(chat_id: number, msg_id: number) {
        return await this.client.archivedMessage.findFirst({
            where: {
                tg_chatid: chat_id,
                msg_id
            }
        })
    }

    async archiveConversation(sender_chat_id: number, sender_message_id: number, recvr_chat_id: number, recvr_msg_id: number) {
        await this.client.archivedMessage.create({
            data: {
                tg_chatid: sender_chat_id,
                msg_id: sender_message_id,
                reply_to_user_chatid: recvr_chat_id,
                reply_to_msg_id: recvr_msg_id,
                kind: PurposeOfMessage.userConversation,
            }
        })
    }
}

