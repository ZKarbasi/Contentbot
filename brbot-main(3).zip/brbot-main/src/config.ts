export const
    DATABASE_URL = process.env["DATABASE_URL"],
    defaultAdminUsernames = (process.env["ADMINS_USERNAME"] || "hamidb80").split(" "), // usernames separated by space without '@' e.g. "username1 username2 username
    TELEGRAM_BOT_TOKEN_KEY = "TELEGRAM_BOT_TOKEN",
    tgToken = process.env[TELEGRAM_BOT_TOKEN_KEY] || ""
