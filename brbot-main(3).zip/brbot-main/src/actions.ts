import { User } from "@prisma/client"
import { bot, db } from "./globe"
import * as M from "./messages"

import { DB, UserMajorState as UMS, UserMinorState as USS, initialInternalUserState } from "./db"
import { glassKeyboardGroup } from "./telegram"
import { Context } from "telegraf"
import { FilledFormParsed, FormFlowField, UserState } from "./db"
import { damn, deduplicateBy } from "./helper"


export async function sendFormFlowFields(u: User) {
  await bot.telegram.sendMessage(u.tg_chatid ?? -1,
    M.formFlowOverviewM(db.theForm),
    glassKeyboardGroup(M.editFormFlowK(db.theForm)))
}

export async function updateForm(ctx: Context, u: User, s: UserState, oldFields: FormFlowField[], newField: FormFlowField) {
  let
    fi = s.data.formFlowIndex,
    resultFields = []

  if (s.master == UMS.flowEditField && fi != null) {
    resultFields = [...oldFields.slice(0, fi), newField, ...oldFields.slice(fi + 1)]
  }
  else if (s.master == UMS.flowAddField) {
    resultFields = [...oldFields, newField]
  }
  else {
    damn()
  }

  await db.setFormFlow(resultFields)
  await ctx.sendMessage(M.registeredM)
  sendFormFlowFields(u)
  returnToHome(u)
}

export function prepareSendMessage(u1chid: number, u2chid: number | null) {
  if (u2chid) {
    db.updateUserState(u1chid,
      UMS.sendMessage,
      USS.doesNotHaveMinorState,
      {
        sendMsg: {
          dest_tgid: u2chid
        }
      })

    bot.telegram.sendMessage(u1chid,
      M.writeYourMessageIWillForwardM,
    )
  }
  else
    bot.telegram.sendMessage(u1chid, M.sorryThisUseHasNotStartedTheBotYetM)

}

export function returnToHome(u: User) {
  db.updateUserStatePacked(u.tg_chatid ?? -1, initialInternalUserState())
}

async function sendFilledFormReport(receiver: User, form: FilledFormParsed, reply_to_message_id?: number) {
  let
    submitter = db.getUser(form.user_chat_id),

    fileIds =
      form.answers
        .filter(a => a.data_type == "file")
        .map(a => a.value),

    textFields =
      form.answers
        .filter(a => a.data_type == "text"),

    m = M.formReportM(form, submitter, textFields),
    k = M.filledFormK(receiver, form),
    chid = receiver.tg_chatid as number

  if (fileIds.length == 0) { // had no docs
    return await bot.telegram.sendMessage(chid, m, {
      ...glassKeyboardGroup(k),
      reply_to_message_id
    })
  }
  else if (fileIds.length == 1) { // had only 1 doc
    return await bot.telegram.sendDocument(chid, fileIds[0], {
      caption: m,
      reply_markup: { inline_keyboard: k },
      reply_to_message_id,
    })
  }
  else { // had many docs
    await bot.telegram.sendMediaGroup(chid, fileIds.map(fid => ({
      type: "document",
      media: fid
    })))
    return await bot.telegram.sendMessage(chid, m, {
      ...glassKeyboardGroup(k),
      reply_to_message_id
    })
  }
}

export async function saveForm(u: User, s: UserState) {
  if (s.data.fillingForm) {
    let
      allFields =
        s
          .data
          .fillingForm
          .answers
          .map((f, i) => ({
            name: db.theForm[i].name,
            data_type: db.theForm[i].data_type,
            value: f.value
          })),

      formRaw = await db.saveFilledForm(
        u.tg_chatid || -1,
        JSON.stringify(allFields),
        new Date())

    return await db.getForm(formRaw.id)
  }
}

export async function sendFilledForm(contacts: User[], form: FilledFormParsed, firstTime: boolean, db: DB) {
  contacts.forEach(async (user) => {
    if (user.tg_chatid) {
      if (firstTime) {
        let res = await sendFilledFormReport(user, form)
        await db.archiveFormReportSent(form.id, res.chat.id, res.message_id)
      }
      else {
        let msg = await db.getArchivedFormReportMsg(user.tg_chatid, form.id)
        if (msg) {
          let res = await sendFilledFormReport(user, form, msg.msg_id)
          await db.updateArchiveFormReportSent(form.id, res.chat.id, res.message_id)
        }
      }
    }
  })
}

export function formRelatedUsers(db: DB, u: User): User[] {
  return deduplicateBy(
    [...db.getAdmins(), u],
    (u) => (u.tg_chatid || -1).toString())
}

export async function askNext(db: DB, u: User, s: UserState, index: number) {
  let chid = u.tg_chatid || -1

  if (index < db.theForm.length) {
    let f = db.theForm[index]
    await bot.telegram.sendMessage(chid, f.name + "\n\n" + f.note)

    if (f.suggestions.length != 0) {
      await bot.telegram.sendMessage(chid,
        M.chooseFromKeyboardOrEnterSomethingM,
        glassKeyboardGroup(M.buttonsOfSuggestionK(f.suggestions)))
    }
  }
  else if (s.data.fillingForm) {
    let form = await saveForm(u, s) as FilledFormParsed
    sendFilledForm(formRelatedUsers(db, u), form, true, db)
    await bot.telegram.sendMessage(chid, db.getFormCompleteMessage())
    returnToHome(u)
  }
  else {
    damn()
  }
}

export async function sendUserContact(ctx: Context, u: User | undefined) {
  if (u)
    await ctx.sendMessage(
      M.userFullInfoM(u),
      glassKeyboardGroup(M.userContactK(u)))
}

export async function sendFormFieldEditReport(ctx: Context, u: User, form: FilledFormParsed) {
  await ctx.sendMessage(
    M.fieldsT + "\n\n" + M.formFieldsM(form.answers),
    glassKeyboardGroup(M.editFilledFormK(u, form)))
}


export function filledFormEditPermission(u: User, form: FilledFormParsed, can: () => void, cannot: () => void) {
  let
    expired = form.acceptances.length > 0,
    theUser = u.tg_chatid == form.user_chat_id

  if (!u.is_admin && expired) cannot()
  else if (u.is_admin || theUser) can()
  else cannot()
}