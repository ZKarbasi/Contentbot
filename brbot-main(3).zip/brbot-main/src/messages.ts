// import { markdownv2 as md2 } from 'telegram-format'
import type { FilledForm, FormAcceptance, User } from '@prisma/client'
import { InlineQueryResultArticle } from 'telegraf/typings/core/types/typegram'
import { cbButton, cbInlineQButton, glassKeyboardGroup } from './telegram'

import { IntlDate } from "intl-date"
import { FilledFormParsed, FormFieldAnswer, FormFlowField, } from './db'
import { makeQueryCmd } from './helper'

// ------- commands

export const
    startC = "/start"
    , debugC = "/debug"
    , sendMessageC = "/send_message"
    , selectUserC = "/select_user"

// ------- callback queries

export const
    cancelB = "cancel"
    , yesB = "yes"
    , noB = "no"
    , ignoreB = "ignore"

    , add_userB = "au"
    , edit_user_nameB = "eun"
    , edit_user_tgidB = "eut"
    , toggle_user_positionB = "tua"
    , remove_userB = "ru"

    , send_messageB = "sm"

    , fill_formB = "ff"
    , select_suggestion_index_from_form_field_idB = "ssifffi"

    , form_flow_optionsB = "ffo"
    , add_form_flow_fieldB = "afff"
    , edit_form_flow_fieldB = "cfef"
    , remove_form_flow_fieldB = "cfrf"
    , edit_form_complete_messageB = "efcm"

    , filled_form_editB = "ffe"
    , filled_form_add_fieldB = "ffaf"
    , filled_form_edit_fieldB = "ffef"
    , filled_form_delete_fieldB = "ffdf"

    , accept_filled_formB = "aff"



// ------- phrases / words

export const
    nameT = "نام"
    , usernameT = "نام کاربری"
    , startAgainT = "شروع دوباره"
    , helpT = "کمک"
    , debugT = "اشکال یابی"
    , yesT = "بله"
    , noT = "نه"
    , positionT = "سمت"
    , adminT = "ادمین"
    , userT = "کاربر"
    , removedT = "حذف شد"
    , normalUserT = "کاربر عادی"
    , byT = "توسط"
    , newValueForFieldW = `مقدار جدید فیلد`
    , thenEnterT = `رو وارد کن`
    , flowT = `روند`
    , fieldsT = "فیلد ها"
    , expectedT = "خواسته شده بود"
    , butT = "ولی"
    , recvdT = "دریافت شد"
    , fileT = "فایل"
    , textT = "متن"


    // ------- choices

    , sendMessageW = "ارسال پیام 📨"
    , fillFormW = "پرکردن فرم 📝"
    , seeUsersW = "کاربران 👥"
    , addUserW = "اضافه کردن کاربر ➕"
    , changeFlowT = "ویرایش روند فرم 📜"
    , removeUserW = "حذف کاربر ❌"
    , editUserNameW = "ویرایش نام 🔤"
    , editUserTgIdW = "ویرایش آیدی 🎫"
    , togglePositionW = "تغییر سمت 👨‍✈️"
    , cancelW = "انصراف ⭕"
    , addFormFieldW = "اضافه کردن فیلد"
    , edit_form_complete_messageW = "تغییر پیام آخر"
    , removeW = "حذف"
    , editW = "ویرایش"
    , acceptW = "تائید"
    , acceptedW = "تائید شد ✅"
    , notAcceptedW = "تائید نشده ⚠"

function userEmojiT(u: User): string {
    return u.is_admin ? "👮" : "👤"
}

// ------- sentences

export const
    helpM = `
با دکمه ها میتونی مسیرت رو پیدا کنی
`
    , anErrorAccordM = `
مشکلی پیش آمد، لاگ های ربات را چک کنید
`   , enterTelegramIdM = `
آیدی تلگرام طرف رو وارد کن:
`
    , somethingWentWrongStartAgainM = `
مشکلی پیش آمده

لطفا دوباره از اول عملیات را انجام دهید
`
    , repliedMessageDoesNotreferToAnythingM = `
پیام ریپلای شده در دیتابیس ذخیره نشده است
`
    , normalUserCannotEditAcceptedFormM = `
کاربر عادی نمیتواند فرم تایید شده را تغییر دهد
`
    , invalidAccessM = `
دسترسی غیرمجاز
`
    , enterUsernameM = `
اسم طرف:
`
    , isUserAdminM = `
آیا طرف ادمینه؟
`
    , pleaseSelectFromButtonsM = `
لطفا از دکمه های موجود استفاده کنید
    `
    , writeYourMessageIWillForwardM = `
پیامت رو بنویس.من واسش فوروارد میکنم
    `
    , sorryThisUseHasNotStartedTheBotYetM = `
این کاربر هنوز وارد ربات نشده
    `
    , weveBeenwaitingForYouM = `
سلام! منتظرت بودیم
    `
    , youCanceledM = `
منصرف شدید
    `
    , fillTheFormThenM = `
خب بریم سراغ فرم
    `
    , chooseFromKeyboardOrEnterSomethingM = `
ی دکمه رو انتخاب کن یا خودت بنویس
    `

    , fileFormatDoesNotMatchM = `
فرمت فایل چیزی نیست که خواسته شده
    `
    , enterNameOfFieldM = `
نام فیلد را وارد کنید
    `
    , enterّFieldNoteM = `
توضیحات فیلد رو وارد کن
    `

    , enterFieldSuggestionM = `
مورد پیشنهادی را وارد کنید
    `
    , doesThisFieldHasSuggestionsM = `
آیا این فیلد جواب های پیشنهادی بیشتری دارد؟
`
    , enterValidFileFormatsM = `
فرمت های مجاز فایل را وارد کنید
با فاصله از هم جدا کنید مثلا

.png .jpg

اگر همه چی قبول فقط ی ستاره(*) بنویس
    `
    , changeFormFillDoneMsgM = `
ویرایش پیام پایان فرم
    `
    , invalidCommandM = `
دستور نامعتبر
    `
    , sorryYoureNotRegisteredM = `
ببخشید ولی شما توی ربات ثبت نشدید
    `
    , itSeemsLikeYouveLostM = `
به نظر میرسه گم شدی
دستور ${startC} رو بزن تا برگردی به خونه
    `
    , typeOfMessageDoesNotSatisfiesFieldTypeW = `
نوع پیام ارسال به نوع فیلد نمیخوره
    `
    , enterLastMessageM = `
 پیام پایانی را وارد کنید
    `
    , registeredM = `
  ثبت شد
    `

    , defaultFormCompleteMsgM = `
فرم شما با موفقیت ثبت شد و برای ادمین ها ارسال شد
    `

    , enterTypeOfFieldM = `
نوع فیلد رو انتخاب کن
    `
    , fieldDeletedFromFormM = `
فیلد مورد نظر از فرم حذف شد!
    `
    , cannotPoisitionOfYourselfM = `
نمیتونی خودت سمت خودت رو تغییر بدی
    `
    , sendTheValueM = `
مقدارش رو بفرست
    `
    , doesThisFieldHasDescription = `
آیا این فیلد  توضیحات دارد؟
`

    , enterFieldNameM = `
اسم فیلد رو وارد کن
    `

    , lastCompleteMessageWasM = `
پیام پایان قبلی این بود:


`

export function acceptedByM(u: User) {
    return `${byT} @${u.username} یا ${u.name} ${acceptedW} `
}

export function enterNewValueForFieldM(field: string) {
    return `${newValueForFieldW} ${field} ${thenEnterT} `
}


export function userFullInfoM(u: User): string {
    return `
${nameT}: ${u.name}
${usernameT}: @${u.username}
${positionT}: ${userEmojiT(u)} ${u.is_admin ? adminT : normalUserT}
`
}

export function userRemovedM(u: User): string {
    return `
${userT} @${u.username} ${removedT}
`
}

function fieldRepr(index: number | null, field: FormFieldAnswer): string {
    let
        prefix = index == null ? "" : `${index + 1}.`,
        val = field.data_type == "file" ? "[file]" : field.value
    return `${prefix}${field.name}: ${val} `
}

function clockNumber(n: number): string {
    return n.toString().padStart(2, '0')
}

function clock(d: Date) {
    return `${clockNumber(d.getHours())}:${clockNumber(d.getMinutes())} `
}

export function formFieldsM(fields: FormFieldAnswer[]) {
    return fields
        .map((f, i) => fieldRepr(i, f))
        .join("\n")
}



export function formReportM(form: FilledFormParsed, sender: User, fields: FormFieldAnswer[]) {
    return `
📬 فرم جدید ارسال شد.

〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
⬅️ اطلاعات کاربر:
🔹 نام ارسال کننده: ${sender.name}
🔹 آیدی ارسال کننده: @${sender.username}

⬅️ اطلاعات فایل محتوا:
${fields.map(f => fieldRepr(null, f)).join('\n')}
📅 تاریخ ارسال فایل: ${IntlDate.from(form.timestamp).format('persian', "yyyy/MM/dd")} ${clock(form.timestamp)}

🎯 وضعیت: ${form.acceptances.length > 0 ? acceptedW : notAcceptedW}

〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️〰️
#️⃣ ${genTag("فرم")} ${genTag("فرم", form.id.toString())}
`
}

export function typeOfMessageDoesNotSatisfiesFieldTypeM(expectedType: string, recvdType: string) {
    return `${typeOfMessageDoesNotSatisfiesFieldTypeW}
${expectedT} "${expectedType}" ${butT} ${recvdT} "${recvdType}"`
}

// ------- inline query result

export function userShortInfoIQ(you: User, other: User): InlineQueryResultArticle {
    return {
        type: "article",
        id: other.username,
        title: `${userEmojiT(other)} @${other.username} - ${other.name} `,
        input_message_content: {
            message_text:
                you.is_admin
                    ? `${selectUserC} ${other.username} `
                    : `${sendMessageC} ${other.username} `
        }
    }
}

function singleFieldViewM(f: FormFlowField, index: number): string {
    let ftype =
        f.data_type == "file"
            ? (f.valid_extensions ? f.valid_extensions.join(" ") : fileT)
            : textT
    return `${index + 1}. ${f.name}: ${ftype}`
}

export function formFlowOverviewM(fields: FormFlowField[]): string {
    return flowT + "\n\n" + fields.map(singleFieldViewM).join('\n')
}

// ------- keyboard


export function helpUsersK() {
    return [
        [
            cbInlineQButton(sendMessageW),
            cbButton(fillFormW, fill_formB)
        ],
    ]
}

export function helpAdminsK() {
    return [
        [
            cbInlineQButton(seeUsersW),
            cbButton(addUserW, add_userB),
        ],
        [
            cbButton(fillFormW, fill_formB),
            cbButton(changeFlowT, form_flow_optionsB),
        ],
    ]
}

export function buttonsOfSuggestionK(seq: string[]) {
    return seq.map((s, i) => [cbButton(s, makeQueryCmd(select_suggestion_index_from_form_field_idB, i.toString()))])
}

export function fieldTypesK() {
    return [[
        cbButton(fileT, "file"),
        cbButton(textT, "text"),
    ]]
}

export function userContactK(u: User) {
    return [
        [
            cbButton(sendMessageW, makeQueryCmd(send_messageB, u.username)),
            cbButton(togglePositionW, makeQueryCmd(toggle_user_positionB, u.username)),
        ],
        [
            cbButton(editUserNameW, makeQueryCmd(edit_user_nameB, u.username)),
            cbButton(editUserTgIdW, makeQueryCmd(edit_user_tgidB, u.username)),
        ],
    ]
}


export function filledFormK(u: User, f: FilledFormParsed) {
    let
        editBtn = cbButton(editW, makeQueryCmd(filled_form_editB, f.id.toString())),
        acceptBtn = cbButton(acceptW, makeQueryCmd(accept_filled_formB, f.id.toString()))

    if (u.is_admin)
        return (f.acceptances.length > 0)
            ? [[editBtn]]
            : [[editBtn, acceptBtn]]
    else
        return (f.acceptances.length > 0)
            ? [[]]
            : [[editBtn]]
}

export function editFilledFormK(u: User, form: FilledFormParsed) {
    let result = []

    for (let i = 0; i < form.answers.length; i++) {
        let
            indexBtn = cbButton((i + 1).toString(), ignoreB),
            editBtn = cbButton(editW, makeQueryCmd(filled_form_edit_fieldB, form.id.toString(), i.toString())),
            delBtn = cbButton(removeW, makeQueryCmd(filled_form_delete_fieldB, form.id.toString(), i.toString())),
            btnList = [indexBtn, editBtn]

        if (u.is_admin)
            btnList.push(delBtn)
        result.push(btnList)
    }

    if (u.is_admin)
        result.push([
            cbButton(addFormFieldW, makeQueryCmd(filled_form_add_fieldB, form.id.toString())),
        ])

    return result
}

export function editFormFlowK(fields: FormFlowField[]) {
    let result = []

    fields.forEach((f, i) => result.push([
        cbButton((i + 1).toString(), ignoreB),
        cbButton(editW, makeQueryCmd(edit_form_flow_fieldB, i.toString())),
        cbButton(removeW, makeQueryCmd(remove_form_flow_fieldB, i.toString())),
    ]))

    result.push([
        cbButton(addFormFieldW, add_form_flow_fieldB),
        cbButton(edit_form_complete_messageW, edit_form_complete_messageB),
    ])

    return result
}

export const
    cancelKeyboard = glassKeyboardGroup([[cbButton(cancelW, cancelB)]]),
    yesNoCancelKeyboard = glassKeyboardGroup([
        [
            cbButton(yesT, yesB),
            cbButton(noT, noB)
        ],
        [cbButton(cancelW, cancelB)],
    ])


export function genTag(...names: string[]) {
    return `#${names.join('_')} `
}
